package com.example.fashionshop.tasks;

import android.content.Context;

import java.util.BitSet;

public class DeleteCartItemByIdTask {
    public DeleteCartItemByIdTask(Context applicationContext, int cart_item_id) {
    }
}
