package com.example.fashionshop.tasks;

public class GetAllCategoriesTask {
}
