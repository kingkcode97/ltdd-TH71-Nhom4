package com.example.fashionshop.models;

public class ExpandedMenuModel {

    String iconName = "";
//    int iconImg = -1; // menu icon resource id

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
    }


//    public int getIconImg() {
//        return iconImg;
//    }
//    public void setIconImg(int iconImg) {
//        this.iconImg = iconImg;
//    }
}