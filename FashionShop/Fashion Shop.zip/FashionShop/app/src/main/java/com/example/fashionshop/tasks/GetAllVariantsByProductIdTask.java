package com.example.fashionshop.tasks;

import androidx.fragment.app.FragmentActivity;

import com.example.fashionshop.models.multiples.Variants;

import java.util.List;

public class GetAllVariantsByProductIdTask {
}
