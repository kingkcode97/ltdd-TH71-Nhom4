package dfapi;

public class FileRequest {
}
