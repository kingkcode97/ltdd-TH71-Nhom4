package dfapi;

public class BaseAsyncRequest {
}
