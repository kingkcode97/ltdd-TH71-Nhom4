package dfapi;

public class HttpDeleteWithBody {
}
