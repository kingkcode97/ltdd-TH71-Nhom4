package dfapi;

public class HttpPatch {
}
